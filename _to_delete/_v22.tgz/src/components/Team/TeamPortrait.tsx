"use client";

import React from "react";
import Image from "next/image";

interface TeamPortraitProps {
  src: string;
  hoverSrc?: string;
  alt: string;
  /** Fill the parent (cards) rather than sizing intrinsically (leaders). */
  fill?: boolean;
  width?: number;
  height?: number;
  className?: string;
  sizes?: string;
  priority?: boolean;
}

/**
 * A portrait that swaps to a second frame on hover or keyboard focus.
 *
 * Both images are always in the DOM and cross-faded with opacity, so there is
 * no flash while the second one loads and nothing shifts. Where a person has
 * no second frame the same image is used, which simply reads as no effect.
 */
const TeamPortrait: React.FC<TeamPortraitProps> = ({
  src,
  hoverSrc,
  alt,
  fill,
  width,
  height,
  className = "",
  sizes,
  priority,
}) => {
  const second = hoverSrc || src;
  const hasSwap = second !== src;

  const common = fill
    ? { fill: true as const, sizes: sizes ?? "(max-width: 1024px) 50vw, 25vw" }
    : { width: width ?? 544, height: height ?? 722, sizes };

  return (
    <div
      className={`group/portrait relative overflow-hidden ${
        fill ? "h-full w-full" : ""
      } ${className}`}
      tabIndex={hasSwap ? 0 : undefined}
    >
      <Image
        {...common}
        src={src}
        alt={alt}
        quality={90}
        priority={priority}
        className={`${
          fill ? "object-cover" : "h-auto w-full"
        } transition-opacity duration-500 ease-out ${
          hasSwap
            ? "group-hover/portrait:opacity-0 group-focus-within/portrait:opacity-0"
            : ""
        }`}
      />
      {hasSwap ? (
        <Image
          {...common}
          src={second}
          alt=""
          aria-hidden="true"
          quality={90}
          className={`${
            fill ? "object-cover" : "h-auto w-full"
          } absolute inset-0 opacity-0 transition-opacity duration-500 ease-out group-hover/portrait:opacity-100 group-focus-within/portrait:opacity-100`}
        />
      ) : null}
    </div>
  );
};

export default TeamPortrait;
