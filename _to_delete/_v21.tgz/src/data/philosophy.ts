export interface PhilosophyPanel {
  eyebrow: string;
  title: string;
  body?: string;
  /** Used by the values panel instead of a paragraph. */
  items?: { name: string; body: string }[];
}

/**
 * The panels that cycle through the About hero while the video and the
 * background stay put. The first is the page's own heading; the rest are
 * taken from the company profile.
 *
 * NOTE ON CORE VALUES: the profile does not publish a numbered list. These
 * four are the ones its own mission statement names — "quality, consistency,
 * professionalism and integrity" — with the wording drawn from the philosophy
 * section. If there is an official list, replace these and keep the shape.
 */
export const philosophyPanels: PhilosophyPanel[] = [
  {
    eyebrow: "Our philosophy",
    title: "We build solutions, relationships and futures.",
    body: "More than structures. A customer-first approach means we start by understanding what you actually need rather than what is easiest to deliver — and we hold to ethical practice whether or not anyone is checking. The point of the work is to transform lives, by creating homes and communities that empower and endure.",
  },
  {
    eyebrow: "Our mission",
    title: "The highest level of service, to every client, every day.",
    body: "To be the benchmark in quality, consistency, professionalism and integrity — exceeding what clients expect of us, while making Benchmark Building Solutions the employer of choice for the people who do the work.",
  },
  {
    eyebrow: "Our vision",
    title: "The partner clients prefer, and the standard others are measured against.",
    body: "To be the construction, facilities and associated service partner our clients choose first — and to be the benchmark against which our competitors are measured.",
  },
  {
    eyebrow: "Our values",
    title: "Four things we do not trade away.",
    items: [
      {
        name: "Integrity",
        body: "Ethical practice as the default, not the exception — and the same answer whether or not anyone is watching.",
      },
      {
        name: "Quality",
        body: "Work that holds. Standards are held on site, not just written into the contract.",
      },
      {
        name: "Consistency",
        body: "The same standard on the tenth project as on the first, and on the quiet job as on the flagship.",
      },
      {
        name: "Professionalism",
        body: "Straight answers, kept timelines and respect for everyone the project touches.",
      },
    ],
  },
];
