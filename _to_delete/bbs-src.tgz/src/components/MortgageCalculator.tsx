"use client";

import React, { useMemo, useState } from "react";
import Container from "./Container";
import LeadForm from "./LeadForm";

/**
 * JENGA KWAKO AFFORDABILITY
 * -------------------------
 * The question standing between a Jenga Kwako visitor and an enquiry is not
 * "what is a mortgage" - it is "what would this cost me every month, and can
 * I carry it". Until that is answered nobody fills in a form, and the copy
 * cannot answer it because the answer depends on a number only they know.
 *
 * So the page answers it. Move the slider, read the monthly figure, and the
 * enquiry button carries the figures with it - a lead that arrives already
 * saying "I am looking at 6 million over 20 years" is a different
 * conversation from one that says "I am interested".
 *
 * TERMS, which are the client's and are not to be changed without them:
 *   9.5% per annum on reducing balance, up to KES 10.5M, up to 25 years.
 *
 * The arithmetic is the standard amortisation formula
 *   M = P*r / (1 - (1+r)^-n)
 * with r the monthly rate and n the number of months. It is indicative: it
 * excludes arrangement fees, valuation, legal costs and insurance, and the
 * disclaimer below says so on the page rather than in a tooltip.
 */

/** Annual rate on reducing balance. */
const ANNUAL_RATE = 0.095;
/** The KMRC-backed ceiling. */
const MAX_LOAN = 10_500_000;
const MIN_LOAN = 500_000;
const STEP = 100_000;
const TERMS = [10, 15, 20, 25];

const money = (n: number) => `KES ${Math.round(n).toLocaleString("en-US")}`;

const monthlyPayment = (principal: number, years: number) => {
  const r = ANNUAL_RATE / 12;
  const n = years * 12;
  return (principal * r) / (1 - Math.pow(1 + r, -n));
};

const MortgageCalculator: React.FC = () => {
  const [loan, setLoan] = useState(5_000_000);
  const [years, setYears] = useState(25);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const { monthly, total, interest } = useMemo(() => {
    const m = monthlyPayment(loan, years);
    return {
      monthly: m,
      total: m * years * 12,
      interest: m * years * 12 - loan,
    };
  }, [loan, years]);

  const atCap = loan >= MAX_LOAN;

  const prefill = [
    "Jenga Kwako enquiry from the affordability calculator.",
    `Amount considered: ${money(loan)}`,
    `Term: ${years} years`,
    `Indicative monthly repayment at 9.5% on reducing balance: ${money(monthly)}`,
  ].join("\n");

  return (
    <>
      <section
        id="affordability"
        className="surface-light w-full border-t border-[color:var(--rule)] py-16 sm:py-20 lg:py-24"
      >
        <Container>
          <div className="lg:grid lg:grid-cols-[1fr_400px] lg:gap-16 xl:gap-24">
            {/* Controls */}
            <div>
              <p className="eyebrow">What it costs each month</p>
              <h2 className="mt-5">Move the slider.</h2>
              <p className="body-text mt-5 max-w-xl">
                At 9.5% on reducing balance - the KMRC-backed rate we arrange -
                here is what a given amount costs you monthly. Nothing is sent
                anywhere until you choose to send it.
              </p>

              <div className="mt-10">
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <label
                    htmlFor="loan-amount"
                    className="meta font-semibold uppercase tracking-[0.16em]"
                  >
                    Amount
                  </label>
                  <output
                    htmlFor="loan-amount"
                    className="numeral text-[length:var(--type-card)] font-semibold text-[#212466]"
                  >
                    {money(loan)}
                  </output>
                </div>
                <input
                  id="loan-amount"
                  type="range"
                  min={MIN_LOAN}
                  max={MAX_LOAN}
                  step={STEP}
                  value={loan}
                  onChange={(e) => setLoan(Number(e.target.value))}
                  className="mt-4 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[#E3E3E9] accent-[#991212]"
                  aria-describedby="loan-cap-note"
                />
                <div className="mt-2 flex justify-between">
                  <span className="meta">{money(MIN_LOAN)}</span>
                  <span className="meta">{money(MAX_LOAN)}</span>
                </div>
              </div>

              <fieldset className="mt-10">
                <legend className="meta font-semibold uppercase tracking-[0.16em]">
                  Term
                </legend>
                <div className="mt-4 flex flex-wrap gap-3">
                  {TERMS.map((t) => {
                    const on = t === years;
                    return (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setYears(t)}
                        aria-pressed={on}
                        className={`meta rounded-full border px-5 py-2 font-semibold transition-colors ${
                          on
                            ? "border-[#212466] bg-[#212466] text-white"
                            : "border-[color:var(--rule)] hover:border-[color:var(--accent)] hover:text-[color:var(--accent)]"
                        }`}
                      >
                        {t} years
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <p id="loan-cap-note" className="meta mt-8 max-w-xl">
                {atCap
                  ? "KES 10.5M is the ceiling on the facility. If your project runs beyond it - up to about KES 20M - you can still take the mortgage and top up the difference yourself."
                  : "The facility runs up to KES 10.5M, which can also cover buying the plot provided the total stays inside the limit."}
              </p>
            </div>

            {/* The answer */}
            <div className="mt-12 lg:mt-0 lg:self-start">
              <div className="border border-[color:var(--rule)] p-7 sm:p-9">
                <p className="meta uppercase tracking-[0.16em]">
                  Indicative monthly repayment
                </p>
                <p className="numeral mt-3 text-[length:var(--type-hero)] font-semibold leading-none text-[#212466]">
                  {money(monthly)}
                </p>

                <dl className="mt-8 flex flex-col gap-3 border-t border-[color:var(--rule)] pt-6">
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="meta">Total repaid over {years} years</dt>
                    <dd className="meta numeral font-semibold text-[color:var(--text)]">
                      {money(total)}
                    </dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="meta">Of which interest</dt>
                    <dd className="meta numeral font-semibold text-[color:var(--text)]">
                      {money(interest)}
                    </dd>
                  </div>
                </dl>

                <button
                  type="button"
                  onClick={() => setIsFormOpen(true)}
                  className="btn-pill btn-pill-dark mt-8 w-full"
                >
                  Check if you qualify
                </button>

                <p className="meta mt-6 leading-relaxed">
                  Indicative only. Excludes arrangement fees, valuation, legal
                  costs and insurance, and is subject to the lender&rsquo;s
                  assessment of your income and credit record. It is not an
                  offer of finance.
                </p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {isFormOpen && (
        <LeadForm
          onClose={() => setIsFormOpen(false)}
          product="Jenga Kwako"
          prefillNotes={prefill}
        />
      )}
    </>
  );
};

export default MortgageCalculator;
