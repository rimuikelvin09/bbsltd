import React from "react";
import Container from "./Container";
import IntroVideo from "./IntroVideo";
import Reveal from "./Reveal";
import { aboutUsHeroDetails } from "@/data/aboutushero";
import { philosophyPanels } from "@/data/philosophy";

/**
 * WHO WE ARE
 * ----------
 * This was five viewport-heights of pinned scrolling: the video and the navy
 * field held still while the opening statement, the philosophy, the mission,
 * the vision and the values cross-faded through one another. It looked good
 * and it read badly - four of the five panels were invisible at any moment,
 * a visitor could not skim, could not search the page for a word, and could
 * not tell how much was left.
 *
 * It is now an ordinary page: the opening statement and the video make the
 * hero, and the four statements sit below it, all visible, in the order the
 * brand states them. Roughly two screens instead of five, and every word is
 * in the markup for anyone - person or crawler - who wants to read it.
 *
 * It is also a server component again. There is nothing left that needs the
 * browser, so this ships no JavaScript beyond the video player itself.
 *
 * THE WORDING IS THE BRAND'S OWN AND IS NOT TO BE EDITED HERE. It lives in
 * data/philosophy.ts with a note explaining why.
 */

const AboutUsHero: React.FC = () => {
  const [philosophy, mission, vision, values] = philosophyPanels;

  return (
    <section id="about-us-hero" className="surface-dark w-full">
      {/* The opening statement and the film. */}
      <Container
        className="pb-16 lg:pb-24"
        style={{ paddingTop: "calc(var(--header-h, 5rem) + 3rem)" }}
      >
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_minmax(0,560px)] lg:gap-14">
          <div className="order-2 lg:order-1">
            <p className="eyebrow eyebrow-muted">
              {aboutUsHeroDetails.eyebrow}
            </p>
            <h1 className="mt-4">{aboutUsHeroDetails.heading}</h1>
            <p className="lede mt-6 max-w-xl">
              {aboutUsHeroDetails.subheading}
            </p>
          </div>

          <div className="order-1 lg:order-2">
            <IntroVideo
              src={aboutUsHeroDetails.videoSrc}
              captionsSrc={aboutUsHeroDetails.captionsSrc}
              label={aboutUsHeroDetails.videoLabel}
            />
          </div>
        </div>
      </Container>

      {/* What we believe. All of it, at once. */}
      <Container className="border-t border-[color:var(--rule)] py-16 sm:py-20 lg:py-24">
        <Reveal>
          <div className="max-w-4xl">
            <h2 className="t-sub">{philosophy.title}</h2>
            <p className="lede mt-5">{philosophy.body}</p>
          </div>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-x-16 gap-y-12 md:grid-cols-2 lg:mt-16">
          {[mission, vision].map((panel, i) => (
            <Reveal key={panel.title} delay={i * 0.08}>
              <h3 className="t-card">{panel.title}</h3>
              <p className="body-text mt-4">{panel.body}</p>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-14 border-t border-[color:var(--rule)] pt-10 lg:mt-16">
            <h3 className="t-card">{values.title}</h3>
            <ul className="mt-6 flex flex-wrap gap-x-10 gap-y-4">
              {(values.items ?? []).map((item) => (
                <li
                  key={item}
                  className="t-card flex items-center gap-3 text-[color:var(--text)]"
                >
                  <span
                    aria-hidden="true"
                    className="h-1.5 w-1.5 rounded-full bg-[color:var(--accent)]"
                  />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </Container>
    </section>
  );
};

export default AboutUsHero;
