"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Product } from "@/types";
import { generateSlug } from "@/utils";
import Container from "./Container";
import { routerQuestions, routerEntryId } from "@/data/router";

interface ProductRouterProps {
  products: Product[];
}

interface Answered {
  questionId: string;
  optionLabel: string;
}

/**
 * Lands a visitor on the one product page that applies to them, in at most
 * three questions.
 *
 * This exists because the six routes are only obvious once you already know
 * the business. Someone who has just bought a plot does not read "Labour
 * Only" and "Jenga Stress Free" and immediately know which is theirs, and
 * the observed behaviour was to open all six or give up.
 *
 * Two things make it worth its weight rather than decoration:
 *
 *   - It converts. A visitor who answers three questions has self-qualified
 *     and arrives on the product page already knowing it is the right one.
 *   - It reports. Each answer dispatches a `bbs:router` DOM event carrying
 *     the question and the choice. Once GA4 is on the site, one listener
 *     turns this into a breakdown of how much of your traffic has land,
 *     needs financing, or is building from abroad - which no page-view
 *     report can tell you.
 *
 * The whole thing is skippable and never blocks the six cards below it.
 */
const ProductRouter: React.FC<ProductRouterProps> = ({ products }) => {
  const [currentId, setCurrentId] = useState<string>(routerEntryId);
  const [trail, setTrail] = useState<Answered[]>([]);
  const [resolvedTitle, setResolvedTitle] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const current = routerQuestions.find((q) => q.id === currentId);
  const resolved = resolvedTitle
    ? products.find((p) => p.productTitle === resolvedTitle)
    : undefined;

  // Focus moves to the answer, so a keyboard or screen-reader user is told
  // that something happened rather than left on a button that vanished.
  useEffect(() => {
    if (resolved) resultRef.current?.focus();
  }, [resolved]);

  const announce = useCallback((question: string, answer: string) => {
    if (typeof window === "undefined") return;
    window.dispatchEvent(
      new CustomEvent("bbs:router", { detail: { question, answer } }),
    );
  }, []);

  const choose = useCallback(
    (optionLabel: string, next?: string, resolve?: string) => {
      if (!current) return;
      announce(current.question, optionLabel);
      setTrail((prev) => [...prev, { questionId: current.id, optionLabel }]);
      if (resolve) setResolvedTitle(resolve);
      else if (next) setCurrentId(next);
    },
    [current, announce],
  );

  const restart = useCallback(() => {
    setTrail([]);
    setResolvedTitle(null);
    setCurrentId(routerEntryId);
  }, []);

  /** Rewinds to a question already answered, dropping everything after it. */
  const rewindTo = useCallback((index: number) => {
    setTrail((prev) => {
      const target = prev[index];
      if (target) setCurrentId(target.questionId);
      return prev.slice(0, index);
    });
    setResolvedTitle(null);
  }, []);

  const step = trail.length + 1;

  return (
    <section
      id="find-your-route"
      className="surface-light w-full scroll-mt-24 border-b border-[color:var(--rule)] py-16 sm:py-20 lg:py-24"
    >
      <Container>
        <div className="lg:grid lg:grid-cols-[360px_1fr] lg:gap-16 xl:gap-24">
          <div className="lg:self-start">
            <p className="eyebrow">Not sure which applies?</p>
            <h2 className="mt-5">Three questions.</h2>
            <p className="body-text mt-5 max-w-md">
              We build six different ways, and the right one depends on what
              you already have. Answer these and we will point you at it -
              nothing is submitted and nobody calls you.
            </p>
            <p className="meta mt-6">
              Would rather just talk to someone?{" "}
              <Link href="/contact" className="link font-semibold">
                Get in touch
              </Link>
            </p>
          </div>

          <div className="mt-10 lg:mt-0">
            {/* Answers so far. Each one is a way back. */}
            {trail.length > 0 ? (
              <ul className="mb-7 flex flex-wrap items-center gap-2">
                {trail.map((a, i) => (
                  <li key={`${a.questionId}-${i}`}>
                    <button
                      type="button"
                      onClick={() => rewindTo(i)}
                      className="meta inline-flex items-center gap-2 rounded-full border border-[color:var(--rule)] px-4 py-1.5 transition-colors hover:border-[color:var(--accent)] hover:text-[color:var(--accent)]"
                    >
                      {a.optionLabel}
                      <span aria-hidden="true">&times;</span>
                      <span className="sr-only">- change this answer</span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}

            {resolved ? (
              <div
                ref={resultRef}
                tabIndex={-1}
                className="border border-[color:var(--rule)] p-7 outline-none sm:p-10"
              >
                <p className="eyebrow">This is the one</p>
                <h3 className="t-sub mt-4">{resolved.productTitle}</h3>
                <p className="body-text mt-5 max-w-2xl">{resolved.productVp}</p>
                <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-4">
                  <Link
                    href={`/products/${generateSlug(resolved.productTitle)}`}
                    className="btn-pill btn-pill-dark"
                  >
                    See {resolved.productTitle}
                  </Link>
                  <button
                    type="button"
                    onClick={restart}
                    className="link meta font-semibold"
                  >
                    Start again
                  </button>
                </div>
              </div>
            ) : current ? (
              <div>
                <p className="meta mb-5">
                  Question {step} of {routerQuestions.length}
                </p>
                <h3 className="t-sub">{current.question}</h3>
                <ul className="mt-7 flex flex-col">
                  {current.options.map((o) => (
                    <li key={o.label}>
                      <button
                        type="button"
                        onClick={() => choose(o.label, o.next, o.resolve)}
                        className="group flex w-full items-center justify-between gap-6 border-t border-[color:var(--rule)] py-5 text-left transition-colors last:border-b hover:text-[color:var(--accent)]"
                      >
                        <span className="body-text font-medium">{o.label}</span>
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="shrink-0 text-[color:var(--accent)] transition-transform duration-300 group-hover:translate-x-1"
                          aria-hidden="true"
                        >
                          <path d="M5 12h14" />
                          <path d="m12 5 7 7-7 7" />
                        </svg>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      </Container>
    </section>
  );
};

export default ProductRouter;
