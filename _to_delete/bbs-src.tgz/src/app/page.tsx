import Hero from "@/components/Hero";
import ProductsListing from "@/components/ProductListing";
import ProductRouter from "@/components/ProductRouter";
import ProcessSection from "@/components/ProcessSection";
import Logos from "@/components/Logos";
import PortalBanner from "@/components/PortalBanner";
import CTA from "@/components/CTA";
import Testimonials from "@/components/Testimonials";
import Container from "@/components/Container";
import Section from "@/components/Section";
import Reveal from "@/components/Reveal";
import { getProducts } from "@/lib/content";

/**
 * HOME PAGE ORDER
 * 1. Hero              — what this company does, in the first thirty words
 * 2. The process       — how it works, and why that is transparent
 * 3. Which one is me   — three questions that land you on one product
 * 4. The six routes    — the full set, for anyone who would rather browse
 * 5. Client Portal     — the tool that keeps the process visible
 * 6. Logos             — who has trusted them
 * 7. CTA               — the page's one conversion action
 * 8. Testimonials      — closes on client voices, per the Peak-End Rule
 *
 * The hero's button is navigation ("See How It Works"), not a second ask: a
 * first-time visitor is top of funnel. The conversion action appears once,
 * at 7 — with the exception of the Jenga Kwako calculator, which earns its
 * own because a visitor who has worked out their monthly repayment is no
 * longer top of funnel.
 *
 * 3 sits before 4 deliberately. Six named products are only self-explanatory
 * to someone who already knows the business; the router is there for the
 * visitor who cannot tell which one is theirs, and the grid is there for the
 * visitor who can.
 */
const HomePage = async () => {
  const products = await getProducts();

  return (
    <>
      <Hero />
      <ProcessSection />
      <ProductRouter products={products} />
      <ProductsListing products={products} />

      <Container>
        <Reveal>
          <PortalBanner />
        </Reveal>
        <Reveal>
          <Logos />
        </Reveal>
        <Reveal>
          <CTA />
        </Reveal>
        <Reveal>
          <Section
            id="testimonials"
            title="Testimonials"
            description="What Our Clients Say."
          ></Section>
        </Reveal>
      </Container>
      <Reveal>
        <Testimonials />
      </Reveal>
    </>
  );
};

export default HomePage;
