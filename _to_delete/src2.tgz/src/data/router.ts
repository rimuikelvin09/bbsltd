/**
 * "WHICH ONE IS ME?"
 * ------------------
 * Six products is one too many to choose between cold. Observation and
 * verbal feedback both pointed at the same thing: visitors could not tell
 * which route applied to them, so they read all six or none.
 *
 * This is a decision tree, not a quiz. At most three questions, and most
 * paths finish in one or two - the moment an answer determines the outcome
 * on its own, it resolves there rather than asking for politeness.
 *
 * Every option carries `resolve` or `next`, never both and never neither,
 * so the tree cannot dead-end. `resolve` names a product by its title; the
 * slug is derived with generateSlug at render time, so renaming a product
 * in products.ts cannot leave a broken link behind here.
 *
 * The answers are also the most useful analytics on the site: they tell you
 * what proportion of your traffic has land, needs financing, or is abroad -
 * which no page-view report can.
 */

export interface RouterOption {
  label: string;
  /** Product title to land on. Mutually exclusive with `next`. */
  resolve?: string;
  /** Id of the next question. Mutually exclusive with `resolve`. */
  next?: string;
}

export interface RouterQuestion {
  id: string;
  /** Short label for the breadcrumb of answered steps. */
  short: string;
  question: string;
  options: RouterOption[];
}

export const routerQuestions: RouterQuestion[] = [
  {
    id: "start",
    short: "Starting point",
    question: "Where are you starting from?",
    options: [
      { label: "I have land and want to build on it", next: "funding" },
      { label: "I do not have land yet", next: "funding" },
      {
        label: "I already have a building that needs work",
        resolve: "Repairs, Renovations & Remodelling",
      },
    ],
  },
  {
    id: "funding",
    short: "How it is paid for",
    question: "How will the project be paid for?",
    options: [
      { label: "From my own funds", next: "where" },
      { label: "I need financing to start", resolve: "Jenga Kwako" },
      {
        label: "I will buy my own materials and need a team to build",
        resolve: "Labour Only",
      },
      {
        label: "I only need drawings, a BOQ or advice for now",
        resolve: "Building Consultancy",
      },
    ],
  },
  {
    id: "where",
    short: "Where you will be",
    question: "Where will you be while it is built?",
    options: [
      { label: "In Kenya", resolve: "Jenga Stress Free" },
      { label: "Outside Kenya", resolve: "Diaspora Building Solutions" },
    ],
  },
];

/** The first question is always the entry point. */
export const routerEntryId = routerQuestions[0].id;
