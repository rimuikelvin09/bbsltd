"use client";

import React, { useId, useMemo, useState } from "react";
import Link from "next/link";
import Container from "./Container";
import LeadForm from "./LeadForm";

/**
 * JENGA KWAKO AFFORDABILITY
 * -------------------------
 * The question standing between a visitor and an enquiry is not "what is a
 * mortgage" - it is "what would this cost me every month". The copy cannot
 * answer it because the answer depends on a number only they know, so the
 * page answers it instead, and the enquiry button carries the figures with
 * it. A lead that arrives saying "I am looking at 6 million over 20 years"
 * is a different conversation from one that says "I am interested".
 *
 * TERMS, taken from the official Jenga Kwako amortization table in
 * /public/documents/amortizationtable.pdf. Do not change without the client:
 *   9.5% p.a. FIXED on reducing balance
 *   KES 1,000,000 to KES 10,500,000
 *   1 to 25 years - every whole year in that range is on the table
 *
 * The arithmetic is the standard amortisation formula
 *   M = P*r / (1 - (1+r)^-n)
 * and it was checked against six cells of that table (1M/1y, 1M/25y,
 * 2.5M/3y, 5.5M/11y, 8M/20y, 10.5M/25y). It agrees to the cent in all six.
 *
 * WHY THIS SHOWS A SAVING RATHER THAN THE INTEREST
 * An earlier version printed "of which interest", which is true and
 * self-defeating: it invites the reader to dwell on what the money costs at
 * the exact moment we want them to act. The comparison below reframes the
 * same arithmetic around what the rate is worth, and it is a sourced fact
 * rather than a claim about competitors - we publish the CBK's own average
 * and let the reader draw the conclusion. Nothing is hidden: the loan and
 * the total repaid are both on screen, so the interest is a subtraction
 * away for anyone who wants it.
 */

/** Annual rate on reducing balance. Fixed for the whole term. */
const ANNUAL_RATE = 0.095;
/**
 * Average commercial bank lending rate published by the Central Bank of
 * Kenya, July 2026. Update this and MARKET_LABEL together when the CBK
 * publishes a newer figure - the page cites the month on screen, so a stale
 * number here becomes a visibly stale claim rather than a silent one.
 */
const MARKET_RATE = 0.1439;
const MARKET_LABEL = "14.39%";
const MARKET_SOURCE = "Central Bank of Kenya average commercial bank lending rate, July 2026";

const MAX_LOAN = 10_500_000;
const MIN_LOAN = 1_000_000;
const LOAN_STEP = 100_000;
const MIN_YEARS = 1;
const MAX_YEARS = 25;

const money = (n: number) => `KES ${Math.round(n).toLocaleString("en-US")}`;

const monthlyPayment = (principal: number, rate: number, years: number) => {
  const r = rate / 12;
  const n = years * 12;
  return (principal * r) / (1 - Math.pow(1 + r, -n));
};

const MortgageCalculator: React.FC = () => {
  const [loan, setLoan] = useState(5_000_000);
  const [years, setYears] = useState(25);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const uid = useId();

  const { monthly, total, marketMonthly, savedMonthly, savedTotal } = useMemo(() => {
    const m = monthlyPayment(loan, ANNUAL_RATE, years);
    const mk = monthlyPayment(loan, MARKET_RATE, years);
    return {
      monthly: m,
      total: m * years * 12,
      marketMonthly: mk,
      savedMonthly: mk - m,
      savedTotal: (mk - m) * years * 12,
    };
  }, [loan, years]);

  const prefill = [
    "Jenga Kwako enquiry from the affordability calculator.",
    `Amount considered: ${money(loan)}`,
    `Term: ${years} ${years === 1 ? "year" : "years"}`,
    `Indicative monthly repayment at 9.5% fixed on reducing balance: ${money(monthly)}`,
  ].join("\n");

  const sliderClass =
    "mt-4 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[#E3E3E9] accent-[#991212]";

  return (
    <>
      <section
        id="affordability"
        className="surface-light w-full scroll-mt-24 border-t border-[color:var(--rule)] py-16 sm:py-20 lg:py-24"
      >
        <Container>
          <div className="lg:grid lg:grid-cols-[1fr_420px] lg:gap-16 xl:gap-20">
            {/* Controls */}
            <div>
              <p className="eyebrow">What it costs each month</p>
              <h2 className="mt-5">Move the sliders.</h2>
              <p className="body-text mt-5 max-w-xl">
                Jenga Kwako is a KMRC-backed mortgage at{" "}
                <strong>9.5% fixed on reducing balance</strong> — fixed for the
                whole term, so the figure below does not move when the Central
                Bank rate does. Nothing is sent anywhere until you choose to
                send it.
              </p>

              <div className="mt-10">
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <label
                    htmlFor={`${uid}-amount`}
                    className="meta font-semibold uppercase tracking-[0.16em]"
                  >
                    How much you need
                  </label>
                  <output
                    htmlFor={`${uid}-amount`}
                    className="numeral text-[length:var(--type-card)] font-semibold text-[#212466]"
                  >
                    {money(loan)}
                  </output>
                </div>
                <input
                  id={`${uid}-amount`}
                  type="range"
                  min={MIN_LOAN}
                  max={MAX_LOAN}
                  step={LOAN_STEP}
                  value={loan}
                  onChange={(e) => setLoan(Number(e.target.value))}
                  className={sliderClass}
                />
                <div className="mt-2 flex justify-between">
                  <span className="meta">{money(MIN_LOAN)}</span>
                  <span className="meta">{money(MAX_LOAN)}</span>
                </div>
              </div>

              <div className="mt-10">
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <label
                    htmlFor={`${uid}-years`}
                    className="meta font-semibold uppercase tracking-[0.16em]"
                  >
                    How long to pay it back
                  </label>
                  <output
                    htmlFor={`${uid}-years`}
                    className="numeral text-[length:var(--type-card)] font-semibold text-[#212466]"
                  >
                    {years} {years === 1 ? "year" : "years"}
                  </output>
                </div>
                <input
                  id={`${uid}-years`}
                  type="range"
                  min={MIN_YEARS}
                  max={MAX_YEARS}
                  step={1}
                  value={years}
                  onChange={(e) => setYears(Number(e.target.value))}
                  className={sliderClass}
                />
                <div className="mt-2 flex justify-between">
                  <span className="meta">1 year</span>
                  <span className="meta">25 years</span>
                </div>
              </div>

              {/* What the rate is worth. Sourced, and the source is on screen. */}
              <div className="mt-12 border-t border-[color:var(--rule)] pt-8">
                <p className="eyebrow">What the rate is worth</p>
                <dl className="mt-6 flex flex-col gap-4">
                  <div className="flex items-baseline justify-between gap-4 border-b border-[color:var(--rule)] pb-4">
                    <dt className="body-text font-semibold text-[#212466]">
                      Jenga Kwako at 9.5% fixed
                    </dt>
                    <dd className="numeral text-[length:var(--type-card)] font-semibold text-[#212466]">
                      {money(monthly)}
                      <span className="meta font-normal"> /month</span>
                    </dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="body-text">
                      The same loan at {MARKET_LABEL}
                    </dt>
                    <dd className="numeral text-[length:var(--type-card)]">
                      {money(marketMonthly)}
                      <span className="meta"> /month</span>
                    </dd>
                  </div>
                </dl>

                <p className="lede mt-7 max-w-xl">
                  You keep{" "}
                  <strong className="text-[color:var(--accent)]">
                    {money(savedMonthly)} every month
                  </strong>{" "}
                  — {money(savedTotal)} across the {years}{" "}
                  {years === 1 ? "year" : "years"}.
                </p>
                <p className="meta mt-3">{MARKET_SOURCE}.</p>
              </div>
            </div>

            {/* The answer */}
            <div className="mt-12 lg:mt-0 lg:self-start lg:sticky lg:top-28">
              <div className="border border-[color:var(--rule)] p-7 sm:p-9">
                <p className="meta uppercase tracking-[0.16em]">
                  Indicative monthly repayment
                </p>
                <p className="numeral mt-3 text-[length:var(--type-section)] font-semibold leading-none text-[#212466]">
                  {money(monthly)}
                </p>
                <p className="meta mt-3">
                  {money(loan)} over {years}{" "}
                  {years === 1 ? "year" : "years"} at 9.5% fixed
                </p>

                <dl className="mt-7 flex flex-col gap-3 border-t border-[color:var(--rule)] pt-6">
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="meta">Total repaid</dt>
                    <dd className="meta numeral font-semibold text-[color:var(--text)]">
                      {money(total)}
                    </dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="meta">Saved against {MARKET_LABEL}</dt>
                    <dd className="meta numeral font-semibold text-[color:var(--accent)]">
                      {money(savedTotal)}
                    </dd>
                  </div>
                </dl>

                <button
                  type="button"
                  onClick={() => setIsFormOpen(true)}
                  className="btn-pill btn-pill-dark mt-8 w-full"
                >
                  Check if you qualify
                </button>

                <p className="meta mt-6 leading-relaxed">
                  Indicative only. Excludes arrangement fees, valuation, legal
                  costs and insurance. Lending is at the sole discretion of the
                  bank.{" "}
                  <Link
                    href="/documents/amortizationtable.pdf"
                    className="link font-semibold"
                  >
                    Full amortization table
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {isFormOpen && (
        <LeadForm
          onClose={() => setIsFormOpen(false)}
          product="Jenga Kwako"
          prefillNotes={prefill}
        />
      )}
    </>
  );
};

export default MortgageCalculator;
