"use client";

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Container from "./Container";
import { processStages } from "@/data/process";

/**
 * YOUR CONSTRUCTION ROADMAP
 * -------------------------
 * This section used to be six viewport-heights tall with a pinned pane
 * inside it: scrolling advanced the stage instead of moving the page, so a
 * visitor spent roughly five screens of scrolling to read six paragraphs and
 * could not tell how much further there was to go. It was the single
 * largest contributor to the "hard to navigate" feedback.
 *
 * It is now an ordinary scrolling list. All six stages are on the page at
 * once, which matters for three separate reasons:
 *
 *   - Transparency is the point of the section. Hiding five stages behind a
 *     click is a strange way to argue that nothing is hidden.
 *   - Every stage is in the markup, so search engines index the whole
 *     process rather than one stage and five empty panels.
 *   - It costs about a screen and a half instead of six, and every pixel of
 *     that scroll now reveals something new.
 *
 * The rail on the left is orientation, not a control surface: it says where
 * you are and lets you jump, but it never takes the scroll away from you.
 * It is a plain list of anchor links, so it works before JavaScript loads.
 */

const pad = (n: number) => (n + 1).toString().padStart(2, "0");

const stageId = (i: number) => `stage-${pad(i)}`;

const ProcessSection: React.FC = () => {
  const [active, setActive] = useState(0);
  const stageRefs = useRef<(HTMLElement | null)[]>([]);

  // Highlights whichever stage is sitting in the upper third of the
  // viewport. Read-only: nothing here changes the scroll position.
  useEffect(() => {
    const nodes = stageRefs.current.filter(Boolean) as HTMLElement[];
    if (!nodes.length || typeof IntersectionObserver === "undefined") return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort(
            (a, b) => a.boundingClientRect.top - b.boundingClientRect.top,
          )[0];
        if (!visible) return;
        const index = nodes.indexOf(visible.target as HTMLElement);
        if (index >= 0) setActive(index);
      },
      // The band is the upper third, so a stage becomes "current" as it
      // arrives rather than as it leaves.
      { rootMargin: "-20% 0px -60% 0px", threshold: 0 },
    );

    nodes.forEach((n) => observer.observe(n));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="process"
      className="surface-dark relative w-full overflow-hidden py-20 sm:py-24 lg:py-28"
    >
      {/* The flat navy read as a wall. The photograph sits underneath at low
          visibility - enough to give the band texture and depth, not enough to
          compete with the type. The gradient closes to solid navy by the time
          it reaches the stage list, which is both a contrast guarantee and a
          way to avoid stretching a landscape photo down a 1900px section. */}
      <div aria-hidden="true" className="absolute inset-0 z-0">
        <Image
          src="/images/process-bg.jpg"
          alt=""
          fill
          priority={false}
          sizes="100vw"
          className="object-cover object-center"
        />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(33,36,102,0.86)_0%,rgba(33,36,102,0.94)_34%,rgba(33,36,102,1)_62%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_22%_12%,rgba(255,255,255,0.07)_0%,rgba(255,255,255,0)_55%)]" />
      </div>

      <Container className="relative z-10">
        <div className="max-w-2xl">
          <p className="eyebrow eyebrow-muted display-shadow">The process</p>
          <h2 className="display-shadow mt-5">Your construction roadmap</h2>
          <p className="lede display-shadow mt-6">
            Six stages, in order, with what happens at each one. You will know
            which stage your project is in at any point, and what has to
            finish before the next begins.
          </p>
        </div>

        <div className="mt-14 lg:mt-20 lg:grid lg:grid-cols-[210px_1fr] lg:gap-16 xl:gap-24">
          {/* Orientation rail - desktop only. Plain anchors, so it works
              without JavaScript and a crawler follows it. */}
          <nav
            aria-label="Process stages"
            className="hidden lg:block lg:self-start"
            style={{
              position: "sticky",
              top: "calc(var(--header-h, 5rem) + 2.5rem)",
            }}
          >
            <ol className="flex flex-col gap-4 border-l border-[color:var(--rule)]">
              {processStages.map((s, i) => {
                const on = i === active;
                return (
                  <li key={s.name} className="relative">
                    {on ? (
                      <span
                        aria-hidden="true"
                        className="absolute -left-px top-0 h-full w-px bg-[color:var(--accent)]"
                      />
                    ) : null}
                    <a
                      href={`#${stageId(i)}`}
                      aria-current={on ? "step" : undefined}
                      className="block py-1 pl-5 transition-colors duration-200"
                    >
                      <span
                        className={`numeral mb-1 block text-[length:var(--type-eyebrow)] ${
                          on
                            ? "text-[color:var(--accent)]"
                            : "text-[color:var(--text-muted)]"
                        }`}
                      >
                        {pad(i)}
                      </span>
                      <span
                        className={`block text-[length:var(--type-meta)] leading-snug ${
                          on
                            ? "font-semibold text-[color:var(--text)]"
                            : "text-[color:var(--text-muted)]"
                        }`}
                      >
                        {s.name}
                      </span>
                    </a>
                  </li>
                );
              })}
            </ol>
          </nav>

          {/* The stages themselves. All six, always. */}
          <ol className="flex flex-col">
            {processStages.map((s, i) => (
              <li
                key={s.name}
                id={stageId(i)}
                ref={(node) => {
                  stageRefs.current[i] = node;
                }}
                className="scroll-mt-32 border-t border-[color:var(--rule)] py-9 first:border-t-0 first:pt-0 sm:py-11 lg:py-12"
              >
                <div className="flex gap-5 sm:gap-8">
                  <span
                    aria-hidden="true"
                    className="numeral shrink-0 text-[1.75rem] leading-none text-white/25 sm:text-[2.25rem] lg:w-[90px]"
                  >
                    {pad(i)}
                  </span>
                  <div className="min-w-0">
                    <h3 className="t-sub">{s.name}</h3>
                    <p className="body-text mt-4 max-w-2xl">{s.body}</p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Container>
    </section>
  );
};

export default ProcessSection;
