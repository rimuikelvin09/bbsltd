import React from "react";
import Container from "./Container";
import IntroVideo from "./IntroVideo";
import Reveal from "./Reveal";
import { aboutUsHeroDetails } from "@/data/aboutushero";
import { philosophyPanels } from "@/data/philosophy";

/**
 * WHO WE ARE
 * ----------
 * Two bands, and the break between them is the design.
 *
 * The first is navy: the opening statement and the film. The second is
 * paper. An earlier version ran all four statements down the navy as plain
 * stacked paragraphs, and the feedback was exactly right - an unbroken field
 * of one colour with four headings and four blocks of text has no rhythm,
 * and the brand's own words ended up looking like filler.
 *
 * The statements are now a definition list: the name on the left, the
 * statement on the right, hairline rules between. That is the same editorial
 * language the rest of the site speaks - eyebrows, numerals, rules, air -
 * and it is the correct markup, because that is literally what this content
 * is. Core values close the band as a numbered row, which is the one place a
 * numeral earns its place here: five things, and you can count them.
 *
 * THE WORDING IS THE BRAND'S OWN AND IS NOT EDITED HERE. It lives in
 * data/philosophy.ts with a note explaining why.
 */

const AboutUsHero: React.FC = () => {
  const statements = philosophyPanels.filter((p) => p.body);
  const values = philosophyPanels.find((p) => p.items);

  return (
    <>
      {/* The opening statement and the film. */}
      <section id="about-us-hero" className="surface-dark w-full">
        <Container
          className="pb-16 lg:pb-24"
          style={{ paddingTop: "calc(var(--header-h, 5rem) + 3rem)" }}
        >
          <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_minmax(0,560px)] lg:gap-14">
            <div className="order-2 lg:order-1">
              <p className="eyebrow eyebrow-muted">
                {aboutUsHeroDetails.eyebrow}
              </p>
              <h1 className="mt-4">{aboutUsHeroDetails.heading}</h1>
              <p className="lede mt-6 max-w-xl">
                {aboutUsHeroDetails.subheading}
              </p>
            </div>

            <div className="order-1 lg:order-2">
              <IntroVideo
                src={aboutUsHeroDetails.videoSrc}
                captionsSrc={aboutUsHeroDetails.captionsSrc}
                label={aboutUsHeroDetails.videoLabel}
              />
            </div>
          </div>
        </Container>
      </section>

      {/* What we hold to. On paper, so the page breathes after the navy. */}
      <section id="what-we-stand-for" className="surface-light w-full py-16 sm:py-20 lg:py-28">
        <Container>
          <Reveal>
            <p className="eyebrow">What we stand for</p>
          </Reveal>

          <dl className="mt-10 flex flex-col lg:mt-14">
            {statements.map((panel, i) => (
              <Reveal key={panel.title} delay={Math.min(i, 3) * 0.07}>
                <div className="grid grid-cols-1 gap-y-4 border-t border-[color:var(--rule)] py-9 sm:py-11 lg:grid-cols-[280px_1fr] lg:gap-x-16 lg:py-12 xl:grid-cols-[340px_1fr]">
                  <dt className="t-card text-[#212466]">{panel.title}</dt>
                  <dd className="lede max-w-3xl">{panel.body}</dd>
                </div>
              </Reveal>
            ))}
          </dl>

          {values?.items?.length ? (
            <Reveal>
              <div className="border-t border-[color:var(--rule)] pt-9 sm:pt-11 lg:pt-12">
                <p className="t-card text-[#212466]">{values.title}</p>
                <ol className="mt-8 grid grid-cols-2 gap-x-8 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">
                  {values.items.map((item, i) => (
                    <li
                      key={item}
                      className="border-t border-[color:var(--rule)] pt-4"
                    >
                      <span
                        aria-hidden="true"
                        className="numeral block text-[length:var(--type-eyebrow)] text-[color:var(--accent)]"
                      >
                        {(i + 1).toString().padStart(2, "0")}
                      </span>
                      <span className="t-card mt-2 block text-[color:var(--text)]">
                        {item}
                      </span>
                    </li>
                  ))}
                </ol>
              </div>
            </Reveal>
          ) : null}
        </Container>
      </section>
    </>
  );
};

export default AboutUsHero;
