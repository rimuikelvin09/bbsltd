import Hero from "@/components/Hero";
import ProductsListing from "@/components/ProductListing";
import ProcessSection from "@/components/ProcessSection";
import MortgageCalculator from "@/components/MortgageCalculator";
import Logos from "@/components/Logos";
import PortalBanner from "@/components/PortalBanner";
import CTA from "@/components/CTA";
import Testimonials from "@/components/Testimonials";
import Container from "@/components/Container";
import Section from "@/components/Section";
import Reveal from "@/components/Reveal";
import { getProducts } from "@/lib/content";

/**
 * HOME PAGE ORDER
 * 1. Hero              — what this company does, in the first thirty words
 * 2. The process       — how it works, and why that is transparent
 * 3. The six routes    — full-height rows, with the guide riding along
 * 4. Affordability     — the calculator, because money is the real blocker
 * 5. Client Portal     — the tool that keeps the process visible
 * 6. Logos             — who has trusted them
 * 7. CTA               — the page's one conversion action
 * 8. Testimonials      — closes on client voices, per the Peak-End Rule
 *
 * The hero's button is navigation ("See How It Works"), not a second ask: a
 * first-time visitor is top of funnel. The conversion action appears once,
 * at 7 — with the exception of the calculator at 4, which earns its own
 * because a visitor who has just worked out their monthly repayment is no
 * longer top of funnel.
 *
 * 4 follows 3 because "which of these is me" and "can I afford it" are the
 * two questions in that order, and the second one is where enquiries
 * actually come from.
 */
const HomePage = async () => {
  const products = await getProducts();

  return (
    <>
      <Hero />
      <ProcessSection />
      <ProductsListing products={products} />
      <MortgageCalculator />

      <Container>
        <Reveal>
          <PortalBanner />
        </Reveal>
        <Reveal>
          <Logos />
        </Reveal>
        <Reveal>
          <CTA />
        </Reveal>
        <Reveal>
          <Section
            id="testimonials"
            title="Testimonials"
            description="What Our Clients Say."
          ></Section>
        </Reveal>
      </Container>
      <Reveal>
        <Testimonials />
      </Reveal>
    </>
  );
};

export default HomePage;
